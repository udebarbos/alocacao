package br.sp.gov.etec.alocacao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AlocacaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
