package br.sp.gov.etec.alocacao.model;

public class CarroTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Carro c = new Carro();
		c.setCor("amarelo");
		System.out.println(c.getCor());
	}

}
